#!/bin/bash

while [ : ]
do

#
#python bot.py -p +6285271022006 -c doge &>/dev/null/&
#
#python bot.py -p +6288226302382 -c doge &>/dev/null/&
#
#python bot.py -p +628819982627 -c doge &>/dev/null/&
#
#python bot.py -p +6285329092198 -c doge &>/dev/null/&
#
#python bot.py -p +6289606243628 -c doge &>/dev/null/&
#
#python bot.py -p +6289648709718 -c doge &>/dev/null/&



clear # ======================================
echo "\033[1;36m Session 1"
python bot.py -p +12523762414 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +12522841199 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +12522512448 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +12522515429 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +12523576817 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +12522856088 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +12523139305 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +12525011773 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +12523791449 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +12522512303 -c doge &>/dev/null/&
sleep 15s

clear # ======================================
echo "\033[1;36m Session 2"
python bot.py -p +12523026337 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +12522420227 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +12522942303 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +12522495807 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +12523655030 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +12522516601 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +12522384061 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +12522447999 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +12523182770 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +12525570333 -c doge &>/dev/null/&
sleep 15s

clear # ======================================
echo "\033[1;36m Session 3"
python bot.py -p +12522393111 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +12522209800 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +15672441235 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18582645303 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18589357024 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18582760230 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18583717011 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18586826933 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18584286738 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18582276889 -c doge &>/dev/null/&
sleep 15s

clear # ======================================
echo "\033[1;36m Session 4"
python bot.py -p +18587269661 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18584617733 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18589358995 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18583759975 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18583459402 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18583714445 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18586825166 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18582760546 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18586824534 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18582841883 -c doge &>/dev/null/&
sleep 15s

clear # ======================================
echo "\033[1;36m Session 5"
python bot.py -p +18583650171 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18582561551 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18584286663 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18583564611 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18584287377 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18587326665 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18583714077 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18586827706 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18583650599 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18586821330 -c doge &>/dev/null/&
sleep 15s

clear # ======================================
echo "\033[1;36m Session 6"
python bot.py -p +18584807150 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18584008828 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18584137621 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18587269906 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18586090711 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18586178013 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18582644876 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18582833663 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18583713703 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18584656672 -c doge &>/dev/null/&
sleep 15s

clear # ======================================
echo "\033[1;36m Session 7"
python bot.py -p +18586146630 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18584656955 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18584016066 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18587323442 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18584806005 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +16153984769 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +17323073320 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18583040964 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +17328207016 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +17323661330 -c doge &>/dev/null/&
sleep 15s

clear # ======================================
echo "\033[1;36m Session 8"
python bot.py -p +18583717500 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +17327044258 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +17323946773 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +17328357071 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +17313268799 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +17312581134 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +17314424513 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +17324366106 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +17329636252 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18586821280 -c doge &>/dev/null/&
sleep 15s

clear # ======================================
echo "\033[1;36m Session 9"
python bot.py -p +17329077223 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +15853573999 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18583763824 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +15855027582 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18587323534 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +15853080904 -c doge &>/dev/null/&
sleep 15s
python bot.py -p +18586820980 -c doge &>/dev/null/&



clear # ======================================
echo "\033[1;36m🔔 Please wait to change  join channel in 3 seconds..."
sleep 2s
echo "\033[1;36m🔔 Please wait to change join channel in 2 seconds..."
sleep 2s
echo "\033[1;36m🔔 Please wait to change join channel in 1 seconds..."
sleep 2s

# ======================================

clear # ======================================
echo "\033[1;36m Session 1"
python join.py +12523762414 &>/dev/null/&
sleep 10s
python join.py +12522841199 &>/dev/null/&
sleep 10s
python join.py +12522512448 &>/dev/null/&
sleep 10s
python join.py +12522515429 &>/dev/null/&
sleep 10s
python join.py +12523576817 &>/dev/null/&
sleep 10s
python join.py +12522856088 &>/dev/null/&
sleep 10s
python join.py +12523139305 &>/dev/null/&
sleep 10s
python join.py +12525011773 &>/dev/null/&
sleep 10s
python join.py +12523791449 &>/dev/null/&
sleep 10s
python join.py +12522512303 &>/dev/null/&
sleep 10s

clear # ======================================
echo "\033[1;36m Session 2"
python join.py +12523026337 &>/dev/null/&
sleep 10s
python join.py +12522420227 &>/dev/null/&
sleep 10s
python join.py +12522942303 &>/dev/null/&
sleep 10s
python join.py +12522495807 &>/dev/null/&
sleep 10s
python join.py +12523655030 &>/dev/null/&
sleep 10s
python join.py +12522516601 &>/dev/null/&
sleep 10s
python join.py +12522384061 &>/dev/null/&
sleep 10s
python join.py +12522447999 &>/dev/null/&
sleep 10s
python join.py +12523182770 &>/dev/null/&
sleep 10s
python join.py +12525570333 &>/dev/null/&
sleep 10s

clear # ======================================
echo "\033[1;36m Session 3"
python join.py +12522393111 &>/dev/null/&
sleep 10s
python join.py +12522209800 &>/dev/null/&
sleep 10s
python join.py +15672441235 &>/dev/null/&
sleep 10s
python join.py +18582645303 &>/dev/null/&
sleep 10s
python join.py +18589357024 &>/dev/null/&
sleep 10s
python join.py +18582760230 &>/dev/null/&
sleep 10s
python join.py +18583717011 &>/dev/null/&
sleep 10s
python join.py +18586826933 &>/dev/null/&
sleep 10s
python join.py +18584286738 &>/dev/null/&
sleep 10s
python join.py +18582276889 &>/dev/null/&
sleep 10s

clear # ======================================
echo "\033[1;36m Session 4"
python join.py +18587269661 &>/dev/null/&
sleep 10s
python join.py +18584617733 &>/dev/null/&
sleep 10s
python join.py +18589358995 &>/dev/null/&
sleep 10s
python join.py +18583759975 &>/dev/null/&
sleep 10s
python join.py +18583459402 &>/dev/null/&
sleep 10s
python join.py +18583714445 &>/dev/null/&
sleep 10s
python join.py +18586825166 &>/dev/null/&
sleep 10s
python join.py +18582760546 &>/dev/null/&
sleep 10s
python join.py +18586824534 &>/dev/null/&
sleep 10s
python join.py +18582841883 &>/dev/null/&
sleep 10s

clear # ======================================
echo "\033[1;36m Session 5"
python join.py +18583650171 &>/dev/null/&
sleep 10s
python join.py +18582561551 &>/dev/null/&
sleep 10s
python join.py +18584286663 &>/dev/null/&
sleep 10s
python join.py +18583564611 &>/dev/null/&
sleep 10s
python join.py +18584287377 &>/dev/null/&
sleep 10s
python join.py +18587326665 &>/dev/null/&
sleep 10s
python join.py +18583714077 &>/dev/null/&
sleep 10s
python join.py +18586827706 &>/dev/null/&
sleep 10s
python join.py +18583650599 &>/dev/null/&
sleep 10s
python join.py +18586821330 &>/dev/null/&
sleep 10s

clear # ======================================
echo "\033[1;36m Session 6"
python join.py +18584807150 &>/dev/null/&
sleep 10s
python join.py +18584008828 &>/dev/null/&
sleep 10s
python join.py +18584137621 &>/dev/null/&
sleep 10s
python join.py +18587269906 &>/dev/null/&
sleep 10s
python join.py +18586090711 &>/dev/null/&
sleep 10s
python join.py +18586178013 &>/dev/null/&
sleep 10s
python join.py +18582644876 &>/dev/null/&
sleep 10s
python join.py +18582833663 &>/dev/null/&
sleep 10s
python join.py +18583713703 &>/dev/null/&
sleep 10s
python join.py +18584656672 &>/dev/null/&
sleep 10s

clear # ======================================
echo "\033[1;36m Session 7"
python join.py +18586146630 &>/dev/null/&
sleep 10s
python join.py +18584656955 &>/dev/null/&
sleep 10s
python join.py +18584016066 &>/dev/null/&
sleep 10s
python join.py +18587323442 &>/dev/null/&
sleep 10s
python join.py +18584806005 &>/dev/null/&
sleep 10s
python join.py +16153984769 &>/dev/null/&
sleep 10s
python join.py +17323073320 &>/dev/null/&
sleep 10s
python join.py +18583040964 &>/dev/null/&
sleep 10s
python join.py +17328207016 &>/dev/null/&
sleep 10s
python join.py +17323661330 &>/dev/null/&
sleep 10s

clear # ======================================
echo "\033[1;36m Session 8"
python join.py +18583717500 &>/dev/null/&
sleep 10s
python join.py +17327044258 &>/dev/null/&
sleep 10s
python join.py +17323946773 &>/dev/null/&
sleep 10s
python join.py +17328357071 &>/dev/null/&
sleep 10s
python join.py +17313268799 &>/dev/null/&
sleep 10s
python join.py +17312581134 &>/dev/null/&
sleep 10s
python join.py +17314424513 &>/dev/null/&
sleep 10s
python join.py +17324366106 &>/dev/null/&
sleep 10s
python join.py +17329636252 &>/dev/null/&
sleep 10s
python join.py +18586821280 &>/dev/null/&
sleep 10s

clear # ======================================
echo "\033[1;36m Session 9"
python join.py +17329077223 &>/dev/null/&
sleep 10s
python join.py +15853573999 &>/dev/null/&
sleep 10s
python join.py +18583763824 &>/dev/null/&
sleep 10s
python join.py +15855027582 &>/dev/null/&
sleep 10s
python join.py +18587323534 &>/dev/null/&
sleep 10s
python join.py +15853080904 &>/dev/null/&
sleep 10s
python join.py +18586820980 &>/dev/null/&




# ======================================
x=7200
while [ $x -gt 0 ]
do
sleep 1s
clear
echo "\033[1;36m Next to the claim, you have \033[39;1m$x \033[1;36mSeconds left"
x=$(( $x - 1 ))
done
done