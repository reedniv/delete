import json,re,sys,os
import argparse
from time import sleep
import time

from time import localtime
import datetime as dt
import logging
import threading
# from datetime import datetime
#import asyncio 
#from urllib import request
#from urllib.error import URLError
#import stat
# from urllib.request import urlopen, request
tx=time.localtime()
hr=tx.tm_hour
mn=tx.tm_min
sc=tx.tm_sec
xtime=('{}:{}:{}'.format(hr,mn,sc))
log_format = "%I:%M:%S %p - %d/%m/%Y"
ptime = time.strftime("%H:%M:%S")

Iterations = 555
for k in range(Iterations+1):
    # some code to execute here ...
    percentage = k / Iterations
    time_msg = "\rRunning Progress at {0:.100%} ".format(percentage)
#    sys.stdout.write(time_msg)

wd = "data/wallet.json"
try:
   import colorama
   from colorama import Fore, Back, Style
   colorama.init(autoreset=True)
   hijau = Style.RESET_ALL+Style.BRIGHT+Fore.GREEN
   res = Style.RESET_ALL
   abu2 = Style.DIM+Fore.WHITE
   putih = Style.RESET_ALL+Style.BRIGHT+Fore.WHITE
   ungu2 = Style.NORMAL+Fore.MAGENTA
   ungu = Style.RESET_ALL+Style.BRIGHT+Fore.MAGENTA
   hijau2 = Style.NORMAL+Fore.GREEN
   yellow2 = Style.NORMAL+Fore.YELLOW
   yellow = Style.RESET_ALL+Style.BRIGHT+Fore.YELLOW
   red2 = Style.NORMAL+Fore.RED
   red = Style.RESET_ALL+Style.BRIGHT+Fore.RED
   cyan = Style.RESET_ALL+Style.BRIGHT+Fore.CYAN
   cyan2 = Style.NORMAL+Fore.CYAN
   des = Style.BRIGHT+Fore.GREEN+"『🔥』"
   kur1 = Style.BRIGHT+Fore.RED+"["
   kur2 = Style.BRIGHT+Fore.RED+"]"
except:
   print ("Please Install Modul Colorama!!\n\n\n")
   sys.exit()

try:
   import requests
   from bs4 import BeautifulSoup
except:
   print ("Please Install Modul Requests & BS4\n\n\n")
   sys.exit()

# from telethon import TelegramClient, sync, events
from telethon import TelegramClient, sync, events
from telethon import functions, types
from telethon.tl.functions.channels import JoinChannelRequest, LeaveChannelRequest
from telethon.tl.functions.messages import GetHistoryRequest, GetBotCallbackAnswerRequest, ImportChatInviteRequest, AddChatUserRequest
from telethon.errors import SessionPasswordNeededError
from telethon.errors import FloodWaitError


logging.basicConfig(filename='reports/error.log', filemode='w', format='%(asctime)s %(message)s', datefmt='%I:%M:%S %p - %d/%m/%Y', level=logging.ERROR)
logging.error('Have a something error')

parser = argparse.ArgumentParser(description='PREMIUM Version 2.0 Auto Withdrawal')
parser.add_argument(
    '-p','--phone',
    help='Enter Your Phone Number.\nExemple +(code country) xxx-xxx-xxx',required=True)
parser.add_argument(
    '-c','--channel',
    help='Enter Your Channel Currency.\nExample DOGE,LTC,BTC,BCH,ZEC',required=True)

logging.basicConfig(filename='reports/info.log', filemode='w', level=logging.INFO)
#logging.info('info on run script')
logging.info("Downloading data... {0}".format(dt.datetime.now().strftime(log_format)))
argument = parser.parse_args()

#banner = request('https:// URLtujuan.com/', headers=headers, method='GET')
#    with urlopen(req) as resp:
#        data = json.loads(resp.read().decode('utf-8'))

banner = """
"""+Style.BRIGHT+Fore.CYAN+"""

██╗  ██╗ ██████╗ ██████╗ ██████╗ ███████╗
╚██╗██╔╝██╔════╝██╔═══██╗██╔══██╗██╔════╝
 ╚███╔╝ ██║     ██║   ██║██║  ██║█████╗  
 ██╔██╗ ██║     ██║   ██║██║  ██║██╔══╝  
██╔╝ ██╗╚██████╗╚██████╔╝██████╔╝███████╗
╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝
"""+Style.RESET_ALL+Style.BRIGHT+Fore.WHITE+"""                Mr. Alliance - Xcode Team
                 """+kur1+Style.RESET_ALL+Style.BRIGHT+Fore.GREEN+""" MULTI AUTO CLICK BOT """ +kur2

if not os.path.exists("session"):
    os.makedirs("session")

def login(nomor):
  global client
  api_id = 1090236
  api_hash = 'ae3c6bba468b360fc6d987513cbc03af'
  phone_number = nomor

  client = TelegramClient("session/"+phone_number, api_id, api_hash)
  client.connect()
  if not client.is_user_authorized():
    try:
      client.send_code_request(phone_number)
      me = client.sign_in(phone_number, input('\n\n\n\033[1;36mEnter Your Code : '))
    except SessionPasswordNeededError:
      passw = input("\033[1;36mYour 2fa Password : ")
      me = client.start(phone_number,passw)
  me = client.get_me()

  logging.basicConfig(filename='reports/debug.log', filemode='w', format='%(asctime)s %(message)s', datefmt='%I:%M:%S %p - %d/%m/%Y', level=logging.DEBUG)
  logging.debug("Debugging is a some bug.. {0}".format(dt.datetime.now().strftime(log_format)))
  os.system("clear")
  print (banner)
  sleep(1)

  print (f"\n\n\n{hijau}⭕ PREMIUM Version 2.0 Auto Withdrawal ⭕")
  print (f"{red}========================================") 
  print (f"{cyan}Welcome To TeleBot :{res}",me.first_name)
  print (f"{cyan}Telegram Number    :{res}",nomor,f"\n{red}========================================")
  print (f"\n\n{hijau}+++++++++++++++ Dashboard ++++++++++++++ \n") 

def filter(channel):
   global channel_username
   global channel_entity
   global jumlah_wd
   global wallet
   if "Doge" in channel or "DOGE" in channel or "doge" in channel:
       channel_entity=client.get_entity("@Dogecoin_click_bot")
       channel_username="@Dogecoin_click_bot"
       jumlah_wd = float(obj["DOGE"]["Amount"])
       wallet = obj["DOGE"]["Address"]
   elif "LTC" in channel or "ltc" in channel:
       channel_entity=client.get_entity("@Litecoin_click_bot")
       channel_username="@Litecoin_click_bot"
       jumlah_wd = float(obj["LTC"]["Amount"])
       wallet = obj["LTC"]["Address"]
   elif "BCH" in channel or "bch" in channel:
       channel_entity=client.get_entity("@BCH_clickbot")
       channel_username="@BCH_clickbot"
       jumlah_wd = float(obj["BCH"]["Amount"])
       wallet = obj["BCH"]["Address"]
   elif "zec" in channel or "ZEC" in channel or "Zec" in channel:
       channel_entity=client.get_entity("@Zcash_click_bot")
       channel_username="@Zcash_click_bot"
       jumlah_wd = float(obj["ZEC"]["Amount"])
       wallet = obj["ZEC"]["Address"]
   elif "BTC" in channel or "btc" in channel:
       channel_entity=client.get_entity("@BitcoinClick_bot")
       channel_username="@BitcoinClick_bot"
       jumlah_wd = float(obj["BTC"]["Amount"])
       wallet = obj["BTC"]["Address"]
   else:
       print (f"{abu2}[{yellow2}Waiting!{abu2}]{yellow}⛔ Please Check Your Command\n")
       logging.basicConfig(filename='reports/warning.log', filemode='w', format='%(asctime)s %(message)s', datefmt='%I:%M:%S %p - %d/%m/%Y', level=logging.WARNING)
       logging.warning("Warning some issues'.. {0}".format(dt.datetime.now().strftime(log_format)))
       sys.exit()

def tunggu(x):
    sys.stdout.write("\r")
    sys.stdout.write("                                                                ")
    for remaining in range(x, 0, -1):
       sys.stdout.write("\r")
       sys.stdout.write("{}[{}|{}]{} {:2d} {}seconds remaining•>       ".format(abu2,red,abu2,res,remaining,cyan))
       sys.stdout.flush()
       sleep(0.125)
       sys.stdout.write("\r")
       sys.stdout.write("{}[{}/{}]{} {:2d} {}seconds remaining •>      ".format(abu2,yellow,abu2,res,remaining,cyan))
       sys.stdout.flush()
       sleep(0.125)
       sys.stdout.write("\r")
       sys.stdout.write("{}[{}-{}]{} {:2d} {}seconds remaining  •>     ".format(abu2,hijau,abu2,res,remaining,cyan))
       sys.stdout.flush()
       sleep(0.125)
       sys.stdout.write("\r")
       sys.stdout.write("{}[{}\{}]{} {:2d} {}seconds remaining   •>    ".format(abu2,cyan,abu2,res,remaining,cyan))
       sys.stdout.flush()
       sleep(0.125)
       sys.stdout.write("\r")
       sys.stdout.write("{}[{}|{}]{} {:2d} {}seconds remaining    •>   ".format(abu2,ungu,abu2,res,remaining,cyan))
       sys.stdout.flush()
       sleep(0.125)
       sys.stdout.write("\r")
       sys.stdout.write("{}[{}/{}]{} {:2d} {}seconds remaining     •>  ".format(abu2,red,abu2,res,remaining,cyan))
       sys.stdout.flush()
       sleep(0.125)
       sys.stdout.write("\r")
       sys.stdout.write("{}[{}-{}]{} {:2d} {}seconds remaining      •> ".format(abu2,yellow,abu2,res,remaining,cyan))
       sys.stdout.flush()
       sleep(0.125)
       sys.stdout.write("\r")
       sys.stdout.write("{}[{}\{}]{} {:2d} {}seconds remaining       •>".format(abu2,hijau,abu2,res,remaining,cyan))
       sys.stdout.flush()
       sleep(0.125)
    sys.stdout.write("\r                                                  \r")
    sys.stdout.write(f"\r{abu2}[{yellow2}Waiting!{abu2}] {hijau}Getting Reward")

with open(wd, 'r') as f:
#     logging.info("Downloading data... {0}".format(dt.datetime.now().strftime(log_format)))
     logging.info("Downloading data... {0}", filename='reports/history.log', filemode='w', format='%(asctime)s %(message)s', datefmt='%I:%M:%S %p - %d/%m/%Y')

     config=f.read()
     # parse file
     obj = json.loads(config)
     
     
ua={"User-Agent": "Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36"}
c = requests.session()
try:
 logging.info("Creating feature classes... {0}".format(dt.datetime.now().strftime(log_format)))
 login(argument.phone)
 filter(argument.channel)
 for i in range(5000000):
  sys.stdout.write("\r")
  sys.stdout.write("                                                              ")
  sys.stdout.write("\r")
  sys.stdout.write(f"\r{abu2}[{yellow2}Waiting!{abu2}]{yellow} Try To Get Url Ads")
  sys.stdout.flush()
  client.send_message(entity=channel_entity,message="🖥 Visit sites")
  sleep(3)
  posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
  if posts.messages[0].message.find("Sorry, there are no new ads available") != -1:
     print (f"\n{abu2}[{red2}{xtime}{abu2}] {red}🔴 Sorry, there are no new ads available!")
     client.send_message(entity=channel_entity,message="💰 Balance")
     sleep(2)
     posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
     message = posts.messages[0].message
     print (f"\r{abu2}[{hijau2}{xtime}{abu2}]{hijau} 💵 "+message)
     if "Available balance" in message:
        sys.stdout.write("\r                                            \r")
        jum = re.findall( r'([\d.]*\d+)', message)
        if float(jum[0]) > jumlah_wd:
           client.send_message(entity=channel_entity,message="💵 Withdraw")
           sleep(1)
           client.send_message(entity=channel_entity,message=wallet)
           sleep(1)
           client.send_message(entity=channel_entity,message=jum[0])
           sleep(1)
           client.send_message(entity=channel_entity,message=" ✔️ Confirm")
           print (f"\r{abu2}[{hijau2}{xtime}{abu2}]{hijau} ✔️ Success Withdraw",jum[0],channel_username, filename='reports/history.log', filemode='w', format='%(asctime)s %(message)s', datefmt='%I:%M:%S %p - %d/%m/%Y')
        else:
      
# automatically reload
#         if __name__ == '__login__':
#            for remaining in range(3600):
#                  login()
#            asyncio.get_event_loop().login()

           sys.exit()
     sys.exit()
  else:
    try:
     url = posts.messages[0].reply_markup.rows[0].buttons[0].url
     sys.stdout.write("\r")
     sys.stdout.write(f"\r{abu2}[{yellow2}Waiting!{abu2}]{yellow} Visit "+url)
     sys.stdout.flush()
     id = posts.messages[0].id
     r = c.get(url, headers=ua, timeout=15, allow_redirects=True)
     soup = BeautifulSoup(r.content,"html.parser")
     if soup.find("div",class_="g-recaptcha") is None and soup.find('div', id="headbar") is None:
        sleep(2)
        posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
        message = posts.messages[0].message
        if posts.messages[0].message.find("You must stay") != -1 or posts.messages[0].message.find("Please stay on") != -1:
           sec = re.findall( r'([\d.]*\d+)', message)
           tunggu(int(sec[0]))
           sleep(1)
           posts = client(GetHistoryRequest(peer=channel_entity,limit=2,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
           messageres = posts.messages[1].message
           sleep(2)
           sys.stdout.write(f"\r{abu2}[{cyan2}{xtime}{abu2}]{cyan} "+messageres+"\n")
        else:
           continue

     elif soup.find('div', id="headbar") is not None:
        for dat in soup.find_all('div',class_="container-fluid"):
            code = dat.get('data-code')
            timer = dat.get('data-timer')
            tokena = dat.get('data-token')
            tunggu(int(timer))
            r = c.post("https://dogeclick.com/reward",data={"code":code,"token":tokena}, headers=ua, timeout=15, allow_redirects=True)
            js = json.loads(r.text)
            sys.stdout.write(f"\r{abu2}[{cyan2}{xtime}{abu2}]{res}{cyan} You earned "+js['reward']+ " " +argument.channel+" for visiting a site!\n", filename='reports/history.log', filemode='w', format='%(asctime)s %(message)s', datefmt='%I:%M:%S %p - %d/%m/%Y')
            logging.exception("Failed on: request.urlretrieve(url, filename) {0}".format(dt.datetime.now().strftime(log_format)))
     else:
        sys.stdout.write("\r")
        sys.stdout.write("                                                                ")
        sys.stdout.write("\r")
        sys.stdout.write(f"\r{abu2}[{yellow2}Waiting!{abu2}] {red}🔴 Captcha Detected")
        sys.stdout.flush()
        sleep(2)
        client(GetBotCallbackAnswerRequest(channel_username,id,data=posts.messages[0].reply_markup.rows[1].buttons[1].data ))
        sys.stdout.write(f"\r{abu2}[{red2}{xtime}{abu2}] {red}🔴 Skip Captcha!       \n")
        sleep(2)
    except KeyboardInterrupt:
         print (f"\n{abu2}[{red2}{xtime}{abu2}] {red}⛔ Exit!")
         logging.info("Done! {0}".format(dt.datetime.now().strftime(log_format)))
         sleep(1)
         sys.exit()
    except:
        sleep(2)
        posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
        message = posts.messages[0].message
        if posts.messages[0].message.find("You must stay") != -1 or posts.messages[0].message.find("Please stay on") != -1:
           sec = re.findall( r'([\d.]*\d+)', message)
           tunggu(int(sec[0]))
           sleep(1)
           posts = client(GetHistoryRequest(peer=channel_entity,limit=2,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
           messageres = posts.messages[1].message
           sleep(2)
           sys.stdout.write(f"\r{abu2}[{cyan2}{xtime}{abu2}]{cyan} "+messageres+"\n")
        else:
           logging.basicConfig(filename='reports/error.log', filemode='w', format='%(asctime)s %(message)s', datefmt='%I:%M:%S %p - %d/%m/%Y', level=logging.ERROR)
           logging.error("Have a something error... {0}".format(dt.datetime.now().strftime(log_format)))

           pass
finally:
       logging.shutdown()
       client.disconnect()
#      client.connect()
#      reload()