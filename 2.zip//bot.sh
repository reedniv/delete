#!/bin/bash
# ======================================

clear
#banner() {
ip=$(w3m -dump -cookie https://ipapi.co/ip);
echo "\033[1;36m __  ______ ___  ____  _____"
echo "\033[1;36m \ \/ / ___/ _ \|  _ \| ____|"
echo "\033[1;36m  \  / |  | | | | | | |  _|"
echo "\033[1;36m  /  \ |__| |_| | |_| | |___"
echo "\033[1;36m /_/\_\____\___/|____/|_____|"
echo "\033[1;m   [ Multi BTC & DOGE & LTC ]"
echo "\033[34;1m============================"
echo "\033[39;1m 📌 Your ip : \033[32;1m"$ip
echo "\033[34;1m============================"
echo "\n\n"
#}
sleep 5s

# ======================================
while [ : ]
do

#echo "\033[1;36m✨ Please wait next accounts..."
#python bot.py -p +6285271022006 -c doge
#echo "\033[1;36m✨ Please wait next accounts..."
#python bot.py -p +6288226302382 -c doge
#echo "\033[1;36m✨ Please wait next accounts..."
#python bot.py -p +628819982627 -c doge
#echo "\033[1;36m✨ Please wait next accounts..."
#python bot.py -p +6285329092198 -c doge
#echo "\033[1;36m✨ Please wait next accounts..."
#python bot.py -p +6289606243628 -c doge
#echo "\033[1;36m✨ Please wait next accounts..."
#python bot.py -p +6289648709718 -c doge



# ======================================
python bot.py -p +12522512303 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +12523026337 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +12522420227 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +12522942303 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +12522495807 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +12523655030 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +12522516601 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +12522384061 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +12522447999 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +12523182770 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +12525570333 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +12522393111 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +12522209800 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +15672441235 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18582645303 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18589357024 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18582760230 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18583717011 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18586826933 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18584286738 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18582276889 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18587269661 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18584617733 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18589358995 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18583759975 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18583459402 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18583714445 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18586825166 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18582760546 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18586824534 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18582841883 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18583650171 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18582561551 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18584286663 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18583564611 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18584287377 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18587326665 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18583714077 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18586827706 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18583650599 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18586821330 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18584807150 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18584008828 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18584137621 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18587269906 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18586090711 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18586178013 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18582644876 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18582833663 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18583713703 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18584656672 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18586146630 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18584656955 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18584016066 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18587323442 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18584806005 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +16153984769 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +17323073320 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18583040964 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +17328207016 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +17323661330 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18583717500 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +17327044258 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +17323946773 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +17328357071 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +17313268799 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +17312581134 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +17314424513 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +17324366106 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +17329636252 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18586821280 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +17329077223 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +15853573999 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18583763824 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +15855027582 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18587323534 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +15853080904 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +18586820980 -c doge


# tusan14111994

#x=7200
#while [ $x -gt 0 ]
#do
#sleep 1s
#clear
#echo "\033[1;36m Next to the join, you have \033[39;1m$x \033[1;36mSeconds left"
#x=$(( $x - 1 ))
#done
#done
# ======================================
echo "\033[1;36m🔔 Please wait to change  join channel in 3 seconds..."
sleep 2s
echo "\033[1;36m🔔 Please wait to change join channel in 2 seconds..."
sleep 2s
echo "\033[1;36m🔔 Please wait to change join channel in 1 seconds..."
sleep 2s

# ======================================

python join.py +12522512303
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +12523026337
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +12522420227
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +12522942303
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +12522495807
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +12523655030
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +12522516601
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +12522384061
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +12522447999
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +12523182770
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +12525570333
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +12522393111
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +12522209800
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +15672441235
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18582645303
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18589357024
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18582760230
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18583717011
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18586826933
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18584286738
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18582276889
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18587269661
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18584617733
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18589358995
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18583759975
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18583459402
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18583714445
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18586825166
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18582760546
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18586824534
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18582841883
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18583650171
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18582561551
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18584286663
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18583564611
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18584287377
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18587326665
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18583714077
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18586827706
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18583650599
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18586821330
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18584807150
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18584008828
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18584137621
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18587269906
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18586090711
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18586178013
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18582644876
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18582833663
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18583713703
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18584656672
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18586146630
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18584656955
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18584016066
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18587323442
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18584806005
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +16153984769
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +17323073320
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18583040964
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +17328207016
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +17323661330
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18583717500
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +17327044258
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +17323946773
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +17328357071
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +17313268799
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +17312581134
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +17314424513
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +17324366106
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +17329636252
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18586821280
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +17329077223
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +15853573999
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18583763824
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +15855027582
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18587323534
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +15853080904
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +18586820980




x=7200
while [ $x -gt 0 ]
do
sleep 1s
clear
echo "\033[1;36m Next to the claim, you have \033[39;1m$x \033[1;36mSeconds left"
x=$(( $x - 1 ))
done
done
