#!/bin/bash

# ======================================
clear
#banner() {
ip=$(w3m -dump -cookie https://ipapi.co/ip);
echo "\033[1;36m __  ______ ___  ____  _____"
echo "\033[1;36m \ \/ / ___/ _ \|  _ \| ____|"
echo "\033[1;36m  \  / |  | | | | | | |  _|"
echo "\033[1;36m  /  \ |__| |_| | |_| | |___"
echo "\033[1;36m /_/\_\____\___/|____/|_____|"
echo "\033[1;m   [ Multi BTC & DOGE & LTC ]"
echo "\033[34;1m============================"
echo "\033[39;1m 📌 Your ip : \033[32;1m"$ip
echo "\033[34;1m============================"
echo "\n\n"
#}
sleep 5s

# ======================================

while [ : ]
do

echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +6285271022006 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +6288226302382 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +628819982627 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +6285329092198 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +6289606243628 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +6289648709718 -c doge
echo "\033[1;36m✨ Please wait next accounts..."
python bot.py -p +6288706671694 -c doge

# ======================================
echo "\033[1;36m🔔 Please wait in 3 seconds..."
sleep 2s
echo "\033[1;36m🔔 Please wait in 2 seconds..."
sleep 2s
echo "\033[1;36m🔔 Please wait in 1 seconds..."
sleep 2s
# ======================================


python join.py +6285329092198
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +6289606243628
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +6289648709718
echo "\033[1;36m✨ Please wait next accounts..."
python join.py +6288706671694


x=7200
while [ $x -gt 0 ]
do
sleep 1s
clear
echo "\033[1;36m Next to the claim, you have \033[39;1m$x \033[1;36mSeconds left"
x=$(( $x - 1 ))
done
done
